﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ServiceModel;
using WpfClientePiano.ServiceReference1;

namespace WpfClientePiano
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IServicioPianoCallback
    {

        //variables para el servicio
        InstanceContext contexto;
        ServicioPianoClient proxy;
        int contador = 0;
        
                public MainWindow()
        {
            InitializeComponent();
            contexto = new InstanceContext(this);
            proxy = new ServicioPianoClient(contexto, "WSDualHttpBinding_IServicioPiano");

        }
             

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // configurando los delegados
            proxy.IniciarSesionCompleted += new EventHandler<IniciarSesionCompletedEventArgs>(proxy_IniciarSesionCompleted);
            proxy.FinalizarSesionCompleted += new EventHandler<FinalizarSesionCompletedEventArgs>(proxy_FinalizarSesionCompleted);
            proxy.PublicarNotaCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(proxy_PublicarNotaCompleted);


            //iniciar sesion
            proxy.IniciarSesionAsync();

        }

        //METODOS CALLBACK 
        void proxy_PublicarNotaCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
          //  contador++;
          //  throw new NotImplementedException();
        }

        void proxy_FinalizarSesionCompleted(object sender, FinalizarSesionCompletedEventArgs e)
        {
            
           // throw new NotImplementedException();
        }

        void proxy_IniciarSesionCompleted(object sender, IniciarSesionCompletedEventArgs e)
        {
          //  throw new NotImplementedException();
        }





        private void cmdPublicarNota_Click(object sender, RoutedEventArgs e)
        {
            int i;
            this.Dispatcher.BeginInvoke(new Action(()=>{
            for (i = 0; i <= 1000; i++)
            {
                proxy.PublicarNotaAsync("hola mundo" + contador.ToString());
                contador++;
            }
            }));



        }

        // ---------------------------------    MÉTODOS IMPLEMENTADO POR LA INTERFECA --------------------------------

        public void TocarNota(string nota)
        {
          //  this.Dispatcher.BeginInvoke(new Action(() => {
         
                txtNotaRecibida.Text = nota;
          //  }));
        }

        public IAsyncResult BeginTocarNota(string nota, AsyncCallback callback, object asyncState)
        {
            throw new NotImplementedException();
        }

        public void EndTocarNota(IAsyncResult result)
        {
            throw new NotImplementedException();
        }
        //---------------------------------------------------------------------------------------------------------------------------
    }
}
