﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
// namespace agregados
using System.ServiceModel.Activation;

namespace ServicioPiano
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class ServicioPiano : IServicioPiano
    {
        //colección sincronizada que contiene a los usuarios suscritos para notificarles por evento las notas
        SynchronizedCollection<IServicioPianoCallBack> Usuarios = new SynchronizedCollection<IServicioPianoCallBack>();



        /// <summary>
        /// Agrega a la colección de usuarios cada usuario que se suscribe al servicio
        /// </summary>
        /// <returns></returns>
        public bool IniciarSesion()
        {
            try
            {
                IServicioPianoCallBack callback = OperationContext.Current.GetCallbackChannel<IServicioPianoCallBack>();
                if (Usuarios.Contains(callback) == false)
                    Usuarios.Add(callback);

                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }


        /// <summary>
        /// Quita o remuve de la colección de usuarios, a los usuarios que han llamado a éste método
        /// para no enviarles las notificaciones de callback
        /// </summary>
        /// <returns></returns>
        public bool FinalizarSesion()
        {
            try
            {
                IServicioPianoCallBack callback = OperationContext.Current.GetCallbackChannel<IServicioPianoCallBack>();
                if (Usuarios.Contains(callback) == true)
                    Usuarios.Remove(callback);

                return true;
            }
            catch (Exception)
            {
                return false;
            }


        }



        public void PublicarNota(string nota)
        {

            //enviar la nota por cada usuario conectado al servicio
            foreach (IServicioPianoCallBack usuario in Usuarios)
            {
                //verifica que la conexión con el usuario siga disponible
                if (((ICommunicationObject)usuario).State == CommunicationState.Opened)
                    usuario.TocarNota(nota);

                else
                    // en caso que se haya desconectado el cliente sin llamar al método FinalizarSesion
                    // aqui se elimina de la colección
                    Usuarios.Remove(usuario);

            }


        }
    }
}
