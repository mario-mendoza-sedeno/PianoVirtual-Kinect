﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Activation;

namespace ServicioPiano
{
    //El servicio debe tener un CallBack hacia el cliente, para notificarle por eventos cada que se presione una tecla
    [ServiceContract(CallbackContract = typeof(IServicioPianoCallBack), SessionMode = SessionMode.Allowed)]
    public interface IServicioPiano
    {
        // TODO: Aceptar un tipo Usuario como argumento para validar las sesiones
        [OperationContract]
        bool IniciarSesion();

        [OperationContract]
        bool FinalizarSesion();

        [OperationContract(IsOneWay = true)]
        void PublicarNota(string nota);

    }

    [ServiceContract]
    public interface IServicioPianoCallBack
    {

        [OperationContract(IsOneWay = true)]
        void TocarNota(string nota);

    }




}



// Se crea un servicio que reciba y envie datos de un tipo llamado Piano, donde sera responsabilidad de cada cliente
// la forma en que se reproduzca cada tecla y sonido